import streamlit as st
from ultralytics import YOLO
import cv2
import tempfile
import os
import shutil

# Set page configuration
st.set_page_config(page_title="Data Drven Animal Species Recognition and Poacher Detection", layout="wide")

# Check if the 'selected_page' exists in session_state; if not, initialize it
if 'selected_page' not in st.session_state:
    st.session_state.selected_page = "Home Page"  # Default page

# Page navigation
page = st.sidebar.radio("Select Page", ["Home Page", "Dataset Description", "Exploratory Data Analysis", "Modelling"], index=["Home Page", "Dataset Description", "Exploratory Data Analysis", "Modelling"].index(st.session_state.selected_page))

if page == "Home Page":
    # Dataset Description Page Code
    st.title("Data Drven Animal Species Recognition and Poacher Detection")
    st.image("cover.png")
    st.header("Introduction")
    st.write("""
    Monitoring of protected areas to curb illegal activities like poaching is a monumental task. Real-time data acquisition has become easier with advances in unmanned aerial vehicles (UAVs) and sensors like TIR cameras, which allow surveillance at night when poaching typically occurs. However, it is still a challenge to accurately and quickly process large amounts of the resulting TIR data. This project aims to harness deep learning technologies to enhance wildlife recognition and poaching detection, providing conservationists, wildlife organisations, and authorities with actionable, real-time data to significantly bolster conservation efforts
    """)

    st.header("Objectives")
    st.write("""
    1. To develop an semi-automated system that is capable of recognising wildlife species and detecting poaching.
    2. To evaluate existing approaches for recognising wildlife species and detecting poaching.
    3. Todeploy a web application for wildlife species recognition and poaching detection
    """)
             
    st.write("""
    **Note: 
    
    In this project, "Poachers" refers to any human detected in the video or image data. This classification is based on the assumption that any human presence within protected areas, especially those not authorized, is potentially involved in poaching. 
    The term "poacher" is used here to highlight the focus of the system on detecting human presence as an indicator of possible unlawful actions, regardless of the specific activity being performed. 
    """)
    

    # Add any other details or charts to explain the dataset further

elif page == "Dataset Description":
    # Dataset Description Page Code
    st.title("Dataset Description")

    st.image("birdsai.png", use_column_width=True)

    st.header("Overview")
    st.write("""
    The Benchmarking IR Dataset for Surveillance with Aerial Intelligence (BIRDSAI, pronounced "bird's-eye") is a long-wave thermal infrared dataset containing nighttime images of animals and poachers in Southern Africa. The dataset allows for benchmarking of algorithms for automatic detection and tracking of humans and animals with both real and synthetic videos. 
    
    It is a public dataset used for the ICVGIP Visual Data Challenge sourced from Labeled Information Library of Alexandria: Biology and Conservation (LILA BC)
    """)

    st.header("Data Format")
    st.write("""
    The dataset is composed of a set of real aerial TIR images and a set of synthetic aerial TIR images (generated with AirSim). 
    - Poachers 
    - Elephant
    - Lion
    - Giraffe
    - Dog
    - Crocodile (Synthetic)
    - Hippo (Synthetic)
    - Zebra (Synthetic)
    - Rhino (Syenthetic)
    """)

    # Add any other details or charts to explain the dataset further

elif page == "Exploratory Data Analysis":
    # Dataset Description Page Code
    st.title("Exploratory Data Analysis")

    st.write("This project only apply the real image dataset to ensure a more accurate, reliable, and practical solution for conservation surveillance.")

    st.header("Class distribution")

    st.image("species_distribution.png", use_column_width=True)

    st.write("""
    This graph suggest class imbalance for the dataset. Elephants dominate the dataset with over 40,000 annotations, making them the most frequently annotated species. In contrast, lions have fewer than 5,000 annotations, representing the least annotated species.
    
    """)

    st.header("Bounding Box Area Distribution")

    st.image("boundingbox_area_distribution.png", use_column_width=True)

    st.write("""
    Most bounding boxes are concentrated in the left area of the graph, indicating that the majority of the bounding boxes are extremely small. This suggests that many of the objects in the dataset occupy a small portion of the image
    """)

    st.header("Bounding Box Area Distribution by Class")
    
    st.image("species_boundingbox_area_distribution.png", use_column_width=True)
    
    st.write("""
    Elephants exhibit the largest average bounding box area, likely reflecting their physical size relative to other species in the dataset. Conversely, lions and "unknown species" are associated with the smallest bounding box areas, which may suggest that these species are either smaller or farther from the camera, leading to reduced bounding box sizes.
    """
    )
    
    st.header("Bounding Box Location Heatmap")
    
    st.image("heatmap_location.png", use_column_width=True)
    
    st.write("""
    The bounding boxes are primarily concentrated in the lower center of the image frames. This spatial distribution might indicate a dataset bias, where most objects are captured in this specific region of the frame. This could be due to factors like camera placement or the natural movement patterns of the animals being studied.
    """
    )

elif page == "Modelling":
    import streamlit as st
    import cv2
    import os
    import tempfile
    import shutil
    from ultralytics import YOLO  # Assuming this is the correct import for YOLO model
    import numpy as np

    def preprocess_frame(frame):
        """Preprocess the frame with Canny edge detection and adaptive thresholding."""
        # Convert to grayscale
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Apply Canny edge detection
        edges = cv2.Canny(gray_frame, 100, 200)

        # Apply adaptive thresholding
        adaptive_thresh = cv2.adaptiveThreshold(gray_frame, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

        # Merge the processed frames into a 3-channel image
        combined_frame = cv2.merge([gray_frame, edges, adaptive_thresh])

        return combined_frame

    st.title("Model")

    # File uploader
    uploaded_video = st.file_uploader("Upload a video for inference (AVI, MP4)", type=["avi", "mp4"])

    st.header("Model Used: YOLO11")
    st.write("""
    Mean Average Precision (mAP): 0.633

    Frame Per Second (FPS): 370

    Number of Parameters: 2.59M
    """)

    if uploaded_video is not None:
        # Save uploaded file to a temporary directory
        temp_dir = tempfile.TemporaryDirectory()
        input_video_path = os.path.join(temp_dir.name, uploaded_video.name)
        with open(input_video_path, "wb") as f:
            f.write(uploaded_video.read())

        st.success("Uploaded video successfully.")

        try:
            # Load YOLO model
            trained_model = YOLO('C:/Users/HP/Documents/UM/Sem5/WIH3001 DSP/Animal_Species_Recognition_and_Poaching_Detection/yolo11n_weighted_trained_2.pt')

            # Open the video using OpenCV
            cap = cv2.VideoCapture(input_video_path)

            # Create a temporary file for the output video
            output_video_path = os.path.join(temp_dir.name, "output_video.mp4")
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = None  # VideoWriter object

            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break

                # Preprocess the frame
                preprocessed_frame = preprocess_frame(frame)

                # Perform inference
                results = trained_model(preprocessed_frame, imgsz=640, conf=0.25)

                # Render the results on the frame
                frame_with_boxes = results[0].plot()

                # Initialize VideoWriter after knowing frame size
                if out is None:
                    height, width, _ = frame_with_boxes.shape
                    out = cv2.VideoWriter(output_video_path, fourcc, cap.get(cv2.CAP_PROP_FPS), (width, height))

                # Write the processed frame to the output video
                out.write(frame_with_boxes)

            cap.release()
            if out:
                out.release()

            st.success("Video processed successfully!")

            # Move the output video to a new path for displaying and downloading
            display_video_path = os.path.join(os.getcwd(), "output_video.mp4")
            shutil.copy(output_video_path, display_video_path)

            # Display the uploaded video
            st.subheader("Uploaded Video")
            st.video(uploaded_video)

            # Display the processed video
            st.subheader("Processed Video")
            st.video(display_video_path)

            # Provide a download link for the processed video
            st.download_button(
                label="Download Processed Video",
                data=open(display_video_path, "rb").read(),
                file_name="output_video.mp4",
                mime="video/mp4"
            )

        except Exception as e:
            st.error(f"An error occurred during video processing: {e}")
        finally:
            # Ensure cleanup happens after Streamlit can read the video
            temp_dir.cleanup()
