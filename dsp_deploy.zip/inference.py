import streamlit as st
from ultralytics import YOLO
import cv2
import tempfile
import os
import shutil


# File uploader
uploaded_video = st.file_uploader("Upload a video for inference (AVI, MP4)", type=["avi", "mp4"])

def preprocess_frame(frame):
    """Preprocess the frame with Canny edge detection and adaptive thresholding."""
    # Convert to grayscale
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Apply Canny edge detection
    edges = cv2.Canny(gray_frame, 100, 200)
    
    # Apply adaptive thresholding
    adaptive_thresh = cv2.adaptiveThreshold(gray_frame, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    
    # Merge the processed frames into a 3-channel image
    combined_frame = cv2.merge([gray_frame, edges, adaptive_thresh])
    
    return combined_frame

if uploaded_video is not None:
    # Save uploaded file to a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    input_video_path = os.path.join(temp_dir.name, uploaded_video.name)
    with open(input_video_path, "wb") as f:
        f.write(uploaded_video.read())

    st.success("Uploaded video successfully.")

    try:
        # Load YOLO model
        trained_model = YOLO('yolo11n_weighted_trained_2.pt')

        # Open the video using OpenCV
        cap = cv2.VideoCapture(input_video_path)

        # Create a temporary file for the output video
        output_video_path = os.path.join(temp_dir.name, "output_video.mp4")
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = None  # VideoWriter object

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Preprocess the frame
            preprocessed_frame = preprocess_frame(frame)

            # Perform inference
            results = trained_model(preprocessed_frame, imgsz=640, conf=0.25)

            # Render the results on the frame
            frame_with_boxes = results[0].plot()

            # Initialize VideoWriter after knowing frame size
            if out is None:
                height, width, _ = frame_with_boxes.shape
                out = cv2.VideoWriter(output_video_path, fourcc, cap.get(cv2.CAP_PROP_FPS), (width, height))

            # Write the processed frame to the output video
            out.write(frame_with_boxes)

        cap.release()
        if out:
            out.release()

        st.success("Video processed successfully!")

        # Move the output video to a new path for displaying and downloading
        display_video_path = os.path.join(os.getcwd(), "output_video.mp4")
        shutil.copy(output_video_path, display_video_path)

        # Provide a download link for the processed video
        st.download_button(
            label="Download Processed Video",
            data=open(display_video_path, "rb").read(),
            file_name="output_video.mp4",
            mime="video/mp4"
        )
    except Exception as e:
        st.error(f"An error occurred during video processing: {e}")
    finally:
        # Ensure cleanup happens after Streamlit can read the video
        temp_dir.cleanup()
