import streamlit as st



# Add content to describe the dataset
st.header("Overview")
st.write("""
This dataset is designed for object detection tasks. It contains videos of various scenes with labeled objects for training a YOLO model. 
This iis a public dataset
""")

st.header("Data Format")
st.write("""
Each video in the dataset is annotated with bounding boxes around the objects of interest. The annotations are stored in a format compatible with YOLO, where each line represents a bounding box and the class index.
- Format: [class_id, x_center, y_center, width, height]
- The data is split into training and validation sets.
""")

st.header("Example Data")
st.write("""
- Video 1: `video1.mp4`
- Annotations: `video1.txt`
- Class labels: 0 = Person, 1 = Car, etc.
""")

# Add any other details or charts to explain the dataset further
